Git repozitorija: https://github.com/Friggid/python34

Atsiskaitymas #3

1. Butina yvesti teisinga failo pavadinima vos yjungus programa.
2. Patenkame y programa.
3. Paspaudus 1 - galima is failo nuskaityti esamus traukinius.
4. Paspaudus 2 - galima surusiuoti traukinius pagal visu vagonu ir lokomatyvu bendra mase arba surusiuoti traukinius pagal laisva vieta likusia atemus kroviniu mase is maksimalios mases visu lokomatyvu ir vagonu. Viskas isrusiuojama didejimo tvarka.
5. Paspaudus 3 - galima prideti nauju lokomatyvu ir/ar vagonu.
6. Paspaudus Q - iseiname is programos.